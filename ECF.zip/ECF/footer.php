<div id="footer-area">
	<ul id="footer-nav">
		<li><a href="terms-and-conditions.php">Terms &amp; Conditions</a></li>
		<li><a href="privacy.php">Privacy</a></li>
		<li><a href="accessibility.php">Accessibility</a></li>
		<li><a href="sitemap.php">Sitemap</a></li>
	</ul>
	<p id="copyright"><?php echo $row88['footer_msg']; ?></p>
</div>
</div>
</div>
<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
try {
var pageTracker = _gat._getTracker("UA-15869132-1");
pageTracker._trackPageview();
} catch(err) {}</script>
</body></html>
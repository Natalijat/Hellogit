<?php
//session_start(); 
require('app.php');
include 'dbConnect.php';
$a2_email = $_GET['email'];

if (!mysql_connect($db_host, $db_user, $db_password))
    die("Can't connect to database");

if (!mysql_select_db($db_db))
    die("Can't select database");
	
$result = mysql_query("SELECT a1_name_organisation, a1_name_applicant, a1_type_organisation, a1_registered_number, a1_organisation_established, a1_website_address, a2_key_person, a2_address, a2_telephone, a2_email, a3_organisation_activities, b1_project_title, b2_project_details, b3_work_date_month, b3_work_date_year, b4_work_place, b5_budget_details1, b5_budget_details2, b5_budget_details3, b6_people_benefit, b7_success_measured, c1_number_people1, c1_number_people2, c1_number_people3, c1_number_people4, c2_trustees_governors, c3_senior_management, c4_key_people, d1_total_income, d2_unrestricted_reserves, d3_financial_position, d4_fund_raising, d5_income_raised, d6_significant_donors, e1_previous_application, e1_successful, e1_list_amounts, e2_reference_name, e2_reference_address, e2_reference_phone, e2_reference_email, e2_reference_relationship, e3_why_ecf, e4_what_difference, terms_agreement
FROM users  
WHERE a2_email = '{$a2_email}'");

$row = mysql_fetch_array( $result );

if(mysql_num_rows($result)==0){ 
Header("Location: index.php");

break;};

$a1_name_organisation = cleanInput(iconv('UTF-8', 'windows-1252',$row['a1_name_organisation']));
$a1_name_applicant = cleanInput(iconv('UTF-8', 'windows-1252',$row['a1_name_applicant']));
$a1_type_organisation = cleanInput(iconv('UTF-8', 'windows-1252',$row['a1_type_organisation']));
$a1_registered_number = cleanInput(iconv('UTF-8', 'windows-1252',$row['a1_registered_number']));
$a1_organisation_established = cleanInput(iconv('UTF-8', 'windows-1252',$row['a1_organisation_established']));
$a1_website_address = cleanInput(iconv('UTF-8', 'windows-1252',$row['a1_website_address']));
$a2_key_person = cleanInput(iconv('UTF-8', 'windows-1252',$row['a2_key_person']));
$a2_address = cleanInput(iconv('UTF-8', 'windows-1252',$row['a2_address']));
$a2_telephone = cleanInput(iconv('UTF-8', 'windows-1252',$row['a2_telephone']));
$a2_email = cleanInput(iconv('UTF-8', 'windows-1252',$row['a2_email']));
$a3_organisation_activities = cleanInput(iconv('UTF-8', 'windows-1252',$row['a3_organisation_activities']));
$b1_project_title = cleanInput(iconv('UTF-8', 'windows-1252',$row['b1_project_title']));
$b2_project_details = cleanInput(iconv('UTF-8', 'windows-1252',$row['b2_project_details']));
$b3_work_date_month = cleanInput(iconv('UTF-8', 'windows-1252',$row['b3_work_date_month']));
$b3_work_date_year = cleanInput(iconv('UTF-8', 'windows-1252',$row['b3_work_date_year']));
$b4_work_place = cleanInput(iconv('UTF-8', 'windows-1252',$row['b4_work_place']));
$b5_budget_details1 = cleanInput(iconv('UTF-8', 'windows-1252',$row['b5_budget_details1']));
$b5_budget_details2 = cleanInput(iconv('UTF-8', 'windows-1252',$row['b5_budget_details2']));
$b5_budget_details3 = cleanInput(iconv('UTF-8', 'windows-1252',$row['b5_budget_details3']));
$b6_people_benefit = cleanInput(iconv('UTF-8', 'windows-1252',$row['b6_people_benefit']));
$b7_success_measured = cleanInput(iconv('UTF-8', 'windows-1252',$row['b7_success_measured']));
$c1_number_people1 = cleanInput(iconv('UTF-8', 'windows-1252',$row['c1_number_people1']));
$c1_number_people2 = cleanInput(iconv('UTF-8', 'windows-1252',$row['c1_number_people2']));
$c1_number_people3 = cleanInput(iconv('UTF-8', 'windows-1252',$row['c1_number_people3']));
$c1_number_people4 = cleanInput(iconv('UTF-8', 'windows-1252',$row['c1_number_people4']));
$c2_trustees_governors = cleanInput(iconv('UTF-8', 'windows-1252',$row['c2_trustees_governors']));
$c3_senior_management = cleanInput(iconv('UTF-8', 'windows-1252',$row['c3_senior_management']));
$c4_key_people = cleanInput(iconv('UTF-8', 'windows-1252',$row['c4_key_people']));
$d1_total_income =cleanInput(iconv('UTF-8', 'windows-1252',$row['d1_total_income']));
$d2_unrestricted_reserves = cleanInput(iconv('UTF-8', 'windows-1252',$row['d2_unrestricted_reserves']));
$d3_financial_position = cleanInput(iconv('UTF-8', 'windows-1252',$row['d3_financial_position']));
$d4_fund_raising = cleanInput(iconv('UTF-8', 'windows-1252',$row['d4_fund_raising']));
$d5_income_raised = cleanInput(iconv('UTF-8', 'windows-1252',$row['d5_income_raised']));
$d6_significant_donors = cleanInput(iconv('UTF-8', 'windows-1252',$row['d6_significant_donors']));
$e1_previous_application = $row['e1_previous_application'];
$e1_successful = $row['e1_successful'];
$e1_list_amounts = cleanInput(iconv('UTF-8', 'windows-1252',$row['e1_list_amounts']));
$e2_reference_name = cleanInput(iconv('UTF-8', 'windows-1252',$row['e2_reference_name']));
$e2_reference_address = cleanInput(iconv('UTF-8', 'windows-1252',$row['e2_reference_address']));
$e2_reference_phone = cleanInput(iconv('UTF-8', 'windows-1252',$row['e2_reference_phone']));
$e2_reference_email = cleanInput(iconv('UTF-8', 'windows-1252',$row['e2_reference_email']));
$e2_reference_relationship = cleanInput(iconv('UTF-8', 'windows-1252',$row['e2_reference_relationship']));
$e3_why_ecf = cleanInput(iconv('UTF-8', 'windows-1252',$row['e3_why_ecf']));
$e4_what_difference = cleanInput(iconv('UTF-8', 'windows-1252',$row['e4_what_difference']));


require('lib/fpdf17/fpdf.php');
class PDF extends FPDF
{

	function Header() {
	global $a1_name_organisation;
	$this->SetFont( 'Arial', 'B', 18 );
	//Frame colour
	$this->SetDrawColor(0,80,180);
	//Fill Colour
    $this->SetFillColor(200,220,255);
	//Text colour
    $this->SetTextColor(220,50,50);
    // Thickness of frame (1 mm)
    $this->SetLineWidth(1);
	$this->Cell( 0, 10, "Application", 1, 1, 'C' );
	$this->ln( 5 );
    }
function Footer()
{
    // Position at 1.5 cm from bottom
    $this->SetY(-15);
    // Arial italic 8
    $this->SetFont('Arial','I',8);
    // Page number
    $this->Cell(0,10,'Page '.$this->PageNo(),0,0,'C');
}

}
$pdf = new PDF();
$pdf->AliasNbPages();
$pdf->AddPage();
$pdf->SetFont('Arial','B',12);
$pdf->Cell(30,10, 'A1.');
$pdf->Ln();
$pdf->SetFont('Arial','',12);
$pdf->Cell(30,10, 'Name of organisation: '.$a1_name_organisation);
$pdf->Ln();
$pdf->Cell(30,10, 'Name of applicant: '.$a1_name_applicant);
$pdf->Ln();
$pdf->Cell(30,10, 'Type of organisation: '.$a1_type_organisation);
$pdf->Ln();
$pdf->Cell(30,10, 'If charity, what is registered number: '.$a1_registered_number);
$pdf->Ln();
$pdf->Cell(30,10, 'Year organisation was established: '.$a1_organisation_established);
$pdf->Ln();
$pdf->Cell(30,10, 'Website address: '.$a1_website_address);
$pdf->Ln();
$pdf->SetFont('Arial','B',12);

$pdf->Cell(30,10, 'A2.');
$pdf->Ln();
$pdf->SetFont('Arial','',12);
$pdf->Cell(30,10, 'Key person dealing with application: '.$a2_key_person);
$pdf->Ln();
$pdf->MultiCell(0,5, 'Address: '.$a2_address);
$pdf->Ln();
$pdf->Cell(30,10, 'Telephone: '.$a2_telephone);
$pdf->Ln();
$pdf->Cell(30,10, 'Email: '.$a2_email);
$pdf->Ln();
$pdf->SetFont('Arial','B',12);

$pdf->Cell(30,10, 'A3.');
$pdf->Ln();
$pdf->SetFont('Arial','',12);
$pdf->MultiCell(0,6, 'Describe you organisation and the main activities: '.$a3_organisation_activities);
$pdf->Ln();
$pdf->AddPage();
$pdf->SetFont('Arial','B',12);

$pdf->Cell(30,10, 'B1.');
$pdf->Ln();
$pdf->SetFont('Arial','',12);
$pdf->Cell(30,10, 'Project title: '.$b1_project_title);
$pdf->Ln();
$pdf->SetFont('Arial','B',12);

$pdf->Cell(30,10, 'B2.');
$pdf->Ln();
$pdf->SetFont('Arial','',12);
$pdf->MultiCell(0,6, 'Project details: '.$b2_project_details);
$pdf->Ln();
$pdf->SetFont('Arial','B',12);

$pdf->Cell(30,10, 'B3.');
$pdf->Ln();
$pdf->SetFont('Arial','',12);
$pdf->Cell(30,10, 'When will the work take place: '.$b3_work_date_month.' '.$b3_work_date_year);
$pdf->Ln();
$pdf->SetFont('Arial','B',12);

$pdf->Cell(30,10, 'B4.');
$pdf->Ln();
$pdf->SetFont('Arial','',12);
$pdf->Cell(30,10, 'Address of where work will take place: '.$b4_work_place);
$pdf->Ln();
$pdf->SetFont('Arial','B',12);

$pdf->Cell(30,10, 'B5.');
$pdf->Ln();
$pdf->SetFont('Arial','',12);
$pdf->Cell(30,10, 'Details of budget information relating to proposal');
$pdf->Ln();
$pdf->MultiCell(0,5, 'i) Details and breakdown of project costs: '.$b5_budget_details1);
$pdf->Ln();
$pdf->MultiCell(0,5, 'ii) Details of funds raised to date, and potential sources of funding: '.$b5_budget_details2);
$pdf->Ln();
$pdf->MultiCell(0,5, 'iii) Amount requested and when required: '.$b5_budget_details3);
$pdf->Ln();
$pdf->SetFont('Arial','B',12);

$pdf->Cell(30,10, 'B6.');
$pdf->Ln();
$pdf->SetFont('Arial','',12);
$pdf->MultiCell(0,5, 'Number of people to benefit directly from the project and over what time period: '.$b6_people_benefit);
$pdf->Ln();
$pdf->SetFont('Arial','B',12);

$pdf->Cell(30,10, 'B7.');
$pdf->Ln();
$pdf->SetFont('Arial','',12);
$pdf->MultiCell(0,5, 'How will success be measured and judged and how often: '.$b7_success_measured);
$pdf->Ln();

$pdf->AddPage();
$pdf->SetFont('Arial','B',12);

$pdf->Cell(30,10, 'C1.');
$pdf->Ln();
$pdf->SetFont('Arial','',12);
$pdf->Cell(30,10, 'Please provide number of people');
$pdf->Ln();
$pdf->Cell(30,10, 'Full time salaried staff: '.$c1_number_people1);
$pdf->Ln();
$pdf->Cell(30,10, 'Active volunteers: '.$c1_number_people2);
$pdf->Ln();
$pdf->Cell(30,10, 'Part time salaried staff: '.$c1_number_people3);
$pdf->Ln();
$pdf->Cell(30,10, 'Trustees/Governors: '.$c1_number_people4);
$pdf->Ln();
$pdf->SetFont('Arial','B',12);

$pdf->Cell(30,10, 'C2.');
$pdf->Ln();
$pdf->SetFont('Arial','',12);
$pdf->MultiCell(0,5, 'Please provide names of up to 5 Trustees/Governors & for each, describe their strengths: '.$c2_trustees_governors);
$pdf->Ln();
$pdf->SetFont('Arial','B',12);

$pdf->Cell(30,10, 'C3.');
$pdf->Ln();
$pdf->SetFont('Arial','',12);
$pdf->MultiCell(0,5, 'Senior management team & how organisation is managed: '.$c3_senior_management);
$pdf->Ln();
$pdf->SetFont('Arial','B',12);

$pdf->Cell(30,10, 'C4.');
$pdf->Ln();
$pdf->SetFont('Arial','',12);
$pdf->MultiCell(0,5, 'Names and job titles of 3 key people plus experience: '.$c4_key_people);
$pdf->Ln();

$pdf->AddPage();
$pdf->SetFont('Arial','B',12);

$pdf->Cell(30,10, 'D1.');
$pdf->Ln();
$pdf->SetFont('Arial','',12);
$pdf->Cell(30,10, 'Organisations total income this year: '.$d1_total_income);
$pdf->Ln();
$pdf->SetFont('Arial','B',12);

$pdf->Cell(30,10, 'D2.');
$pdf->Ln();
$pdf->SetFont('Arial','',12);
$pdf->MultiCell(0,5, 'Amount in unrestricted reserves at end of last financial year and approximately how many months of operating costs does this represent: '.$d2_unrestricted_reserves);
$pdf->Ln();
$pdf->SetFont('Arial','B',12);

$pdf->Cell(30,10, 'D3.');
$pdf->Ln();
$pdf->SetFont('Arial','',12);
$pdf->MultiCell(0,5, 'What is your current financial position and any planned changes in the future: '.$d3_financial_position);
$pdf->Ln();
$pdf->SetFont('Arial','B',12);

$pdf->Cell(30,10, 'D4.');
$pdf->Ln();
$pdf->SetFont('Arial','',12);
$pdf->Cell(30,10, 'How much is spent on fundraising per year: '.$d4_fund_raising);
$pdf->Ln();
$pdf->SetFont('Arial','B',12);

$pdf->Cell(30,10, 'D5.');
$pdf->Ln();
$pdf->SetFont('Arial','',12);
$pdf->Cell(30,10, 'How much income is raised from above activities: '.$d5_income_raised);
$pdf->Ln();
$pdf->SetFont('Arial','B',12);

$pdf->Cell(30,10, 'D6.');
$pdf->Ln();
$pdf->SetFont('Arial','',12);
$pdf->Cell(30,10, 'Please provide names of significant donors (above '.utf8_decode("£").'5,000): '.$d6_significant_donors);
$pdf->Ln();

$pdf->AddPage();
$pdf->SetFont('Arial','B',12);

$pdf->Cell(30,10, 'E1.');
$pdf->Ln();
$pdf->SetFont('Arial','',12);
$pdf->Cell(30,10, 'Previous applications: '.$e1_previous_application);
$pdf->Ln();
$pdf->Cell(30,10, 'Were you successful in obtaining financial support: '.$e1_successful);
$pdf->Ln();
$pdf->Cell(30,10, 'Please list amounts, dates and awards: '.$e1_list_amounts);
$pdf->Ln();
$pdf->SetFont('Arial','B',12);

$pdf->Cell(30,10, 'E2.');
$pdf->Ln();
$pdf->SetFont('Arial','',12);
$pdf->Cell(30,10, 'Contact details of professional person or organisation we can contact for a reference');
$pdf->Ln();
$pdf->Cell(30,10, 'Name: '.$e2_reference_name);
$pdf->Ln();
$pdf->MultiCell(0,5, 'Address: '.$e2_reference_address);
$pdf->Ln();
$pdf->Cell(30,10, 'Telephone: '.$e2_reference_phone);
$pdf->Ln();
$pdf->Cell(30,10, 'Email: '.$e2_reference_email);
$pdf->Ln();
$pdf->Cell(30,10, 'Relationship to your organisation: '.$e2_reference_relationship);
$pdf->Ln();
$pdf->SetFont('Arial','B',12);

$pdf->Cell(30,10, 'E3.');
$pdf->Ln();
$pdf->SetFont('Arial','',12);
$pdf->MultiCell(0,7, 'Why have you chosen the Evan Cornish Foundation: '.$e3_why_ecf);
$pdf->Ln();
$pdf->SetFont('Arial','B',12);

$pdf->Cell(30,10, 'E4.');
$pdf->Ln();
$pdf->SetFont('Arial','',12);
$pdf->MultiCell(0,7, 'What difference will a grant from ECF make to your project: '.$e4_what_difference);
$pdf->Ln();
$pdf->SetFont('Arial','B',12);

//The name of the output file
$pdf->Output($a1_name_organisation.'.pdf', 'D');

?>